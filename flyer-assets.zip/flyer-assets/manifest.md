# Attraccess – Grafik-Assets für Print-Faltblatt

Zusammengestellt für das Marketing-Faltblatt. UI auf **Deutsch**, **Light Mode**,
realistische Demo-Daten (keine echten Personennamen/E-Mails – alle Konten sind
fiktive Personas `vorname.nachname@makerspace.demo`).

- **Quelle der Screenshots:** lokal laufende App (`pnpm serve`) auf einer **isolierten
  Demo-Datenbank** (`storage-demo/`, Kopie der Dev-DB, bereinigt + mit Demo-Daten
  bestückt). Die echte Dev-DB wurde nicht verändert.
- **Maschinen-Demo-Daten:** Lasercutter, 3D-Drucker, CNC-Fräse, Kreissäge,
  Standbohrmaschine (+ Werkstatt-Tür, Lötstation, Vinyl-Plotter), gruppiert in
  Holzwerkstatt / Metallwerkstatt / Digitale Fertigung / Elektroniklabor.
- **Live-Status:** Lasercutter = *In Benutzung*, CNC-Fräse = *In Wartung (gesperrt)*,
  Rest *Verfügbar*. Plus 12 Einweisungen, Wartungs-Zeitpläne, ~146 Nutzungssitzungen.

> **Auflösungs-Hinweis (wichtig für Print):**
> Desktop-Screenshots wurden mit **2560 px Breite** aufgenommen (möglichst breit,
> hohe Pixelzahl). Echtes Geräte-Pixel-Doubling (`devicePixelRatio = 2`) ließ sich
> mit dem Screenshot-Tool für den Desktop nicht erzwingen, daher DPR = 1 bei großer
> Viewport-Breite. **Mobile**-Screenshots sind echtes Retina (DPR 3, 1206 px breit).
> Für Detail-Crops in höchster Qualität bitte aus den `*-full.png` (2560 px)
> nachschneiden – die mitgelieferten `*-crop.png` sind komponentengenaue Ausschnitte
> direkt aus dem DOM (verlustfrei, keine Kompressionsartefakte, PNG).

---

## 1) App-Screenshots (`screenshots/`)

| Datei | Zeigt | Quelle |
|---|---|---|
| `00-login-welcome-desktop.png` | Login-/Willkommens-Screen mit Maskottchen-Hero und Claim „Dein Schlüssel zum Makerspace" | App `/` (Desktop 2560×1440) |
| `01-ressourcenliste-desktop-full.png` | **Ressourcenliste** mit Live-Status-Badges (Verfügbar/In Benutzung/In Wartung), nach Gruppen sortiert; oben Störungs-Hinweis | App `/resources` (Desktop) |
| `01-ressourcenliste-badges-crop.png` | Enger Crop: Gruppe „Holzwerkstatt" mit Badges *In Wartung* + *Verfügbar* | Ausschnitt aus `/resources` |
| `02-ressourcenliste-mobile-full.png` | Ressourcenliste **Mobile** (iPhone, Retina 3×): Hamburger-Menü, Such-/Scan-Leiste, Status-Badges | App `/resources` (Mobile 402×874@3×) |
| `03-ressource-detail-uebersicht-full.png` | **Ressourcen-Detail** (Übersicht): Nutzungssitzung starten, Abrechnung, Doku, letzte Nutzungen | App `/resources/3` |
| `03-detail-nutzungssitzung-crop.png` | Enger Crop: Karte „Nutzungssitzung" mit Start-Button „Ressource verwenden" | Ausschnitt `/resources/3` |
| `04-kiosk-scan-start-full.png` | **„Scan → Maschine startet"**-Moment: Kiosk-Ansicht am Attractap-Terminal, prominenter „Ressource verwenden"-Button | App `/kiosk/resources/3` |
| `05-personen-zugang-einweisung-full.png` | **Zugangs-/Freigabe- + Einweisungsnachweis-Ansicht**: eingewiesene Personen mit Einweisungsdatum (grün gültig / rot nachschulungsfällig), Rollen Einweiser/Wartender | App `/resources/3/people` |
| `05-personen-einweisung-crop.png` | Enger Crop: Einweisungs-/Personen-Tabelle | Ausschnitt `/resources/3/people` |
| `06-wartungsplanung-full.png` | **Wartungsplanung/Erinnerungen**: KPI-Kacheln, offene Wartungsanfrage, Zeitpläne (alle 30 Tage / 100 Std. Nutzung), Verlauf | App `/resources/3/maintenance` |
| `06-wartung-kpi-crop.png` | Enger Crop: KPI-Kacheln (Aktiv / Zeitpläne / Nächste Ausführung / Diesen Monat) | Ausschnitt `/resources/3/maintenance` |
| `07-nutzungsprotokoll-verlauf-full.png` | **Nutzungsprotokoll**: Sitzungen aller Benutzer mit Avataren, Dauer, Live-Badge „In Benutzung", Projektzuordnung | App `/resources/3/history` |
| `07-nutzungsprotokoll-crop.png` | Enger Crop: Nutzungsprotokoll-Tabelle | Ausschnitt `/resources/3/history` |
| `08-benutzerverwaltung-full.png` | **Mitglieder-/Rechteverwaltung**: Nutzerliste, E-Mail-Bestätigung, Berechtigungen (Bonus-Asset / „Verwaltungs-Dashboard") | App `/users` |
| `08-benutzerverwaltung-crop.png` | Enger Crop: Benutzer-Tabelle | Ausschnitt `/users` |

**Hinweis „Dashboard-Übersicht":** Attraccess hat **kein separates Analytics-Dashboard**.
Das operative Dashboard ist die Ressourcenliste (`01`, Live-Status + Störungs-Hinweis);
den **Wartungsstatus** liefert die Wartungs-Ansicht (`06`, KPI-Kacheln), die **Nutzungen**
das Nutzungsprotokoll (`07`). Als zusätzliches Übersichts-Asset liegt die
Benutzerverwaltung (`08`) bei.

---

## 2) Marke (`brand/`)

### Logo

| Datei | Beschreibung |
|---|---|
| `attraccess-lockup-light.svg` | Lockup (Maskottchen + Wortmarke), Wortmarke **schwarz** – für helle Hintergründe. Vektor, transparent. |
| `attraccess-lockup-dark.svg` | Lockup, Wortmarke **weiß** – für dunkle Hintergründe. Vektor, transparent. |
| `attraccess-lockup-light@2400.png` | Lockup hell, 2400×721 px, transparent (aus SVG gerendert). |
| `attraccess-lockup-dark@2400.png` | Lockup dunkel, 2400×721 px, transparent. |
| `attraccess-lockup-light.png` | Lockup hell, Original aus Repo (400×120 px, klein – für Web). |
| `attraccess-lockup-color.svg` | Vollfarb-Vektor-Lockup, Original aus Repo (`apps/api/src/assets/logo.svg`). |
| `attraccess-lockup-color@1200.png` | Vollfarb-Lockup, 1200×361 px. |
| `attraccess-icon.png` | **Nur Maskottchen** (Waschbär im Schlüsselloch), 150×300 px, transparent. |
| `app-icon-512.png` / `app-icon-512-maskable.png` | App-Icon 512×512 (PWA), inkl. maskable-Variante. |
| `apple-touch-icon.png` | 180×180 App-Icon. |
| `favicon.ico` | Favicon, 32×32. |

Quellen: `apps/api/src/assets/logo.{svg,png}`, `apps/frontend/public/{logo.png,favicon.ico,icon-*.png,apple-touch-icon.png}`,
Lockup-Vektor aus Komponente `libs/ui/src/AttraccessLogo.tsx` (Wortmarke = `currentColor`, hier zu hell/dunkel ausgefärbt).

### Markenfarben → siehe `brand/brand-colors.json`

Attraccess definiert **keine eigene Tailwind-Palette**, sondern nutzt die
**HeroUI-v3-Semantik** (`@heroui/styles`, oklch). Werte unten aus der laufenden App
(Light Mode) ausgelesen und nach sRGB-Hex konvertiert. „Primär/Aktion" heißt in
HeroUI v3 **`accent`**.

| Rolle | Hex | Token / Herkunft |
|---|---|---|
| Primär / Aktion (Buttons, Links) | `#0584F7` | `--accent` / `--focus` |
| Erfolg / Status „Verfügbar" | `#17C964` | `--success` |
| Warnung / Status „In Wartung" | `#F4A525` | `--warning` |
| Gefahr / Fehler | `#FE393C` | `--danger` |
| Seiten-Hintergrund (hell) | `#F4F4F5` | `--background` |
| Karten/Oberfläche | `#EEEFF1` | `--surface-secondary` |
| Neutral / Default-Fläche | `#EBEBEC` | `--default` |
| Rahmen / Divider | `#C7C6C6` | `--border-secondary` |
| Text / Vordergrund | `#18191A` | `--foreground` |
| Hintergrund (Dark Mode) | `#18181B` | `--background-inverse` |
| **Marken-Akzent Rosé (Maskottchen-Schlüsselloch)** | `#C57881` | `logo.svg` |
| Logo-Grau (Maskottchen) | `#D9D9D9` | `logo.svg` |

### Schriftarten

Attraccess bindet **keine eigene Webfont** ein – Headline **und** Body nutzen den
**System-Sans-Serif-Stack** (Tailwind-/HeroUI-v3-Default):

```
ui-sans-serif, system-ui, sans-serif, "Apple Color Emoji", "Segoe UI Emoji",
"Segoe UI Symbol", "Noto Color Emoji"
```

Praktisch: San Francisco (macOS/iOS), Segoe UI (Windows), Roboto (Android).
Mono-Stack (z. B. Codes): `ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, …`.
Die **Wortmarke „Attraccess"** im Logo ist eine eigene, abgerundete Sans als
**Vektor-Outline** (keine lebende Schrift; nicht als Font verfügbar).

---

## 3) Hardware-Fotos — **FEHLEN (nicht erfunden)**

Im Repo existieren **keine Produktfotos** der Hardware. Die Hardware-Doku enthält
sogar einen offenen Platzhalter (`<!-- TODO: Screenshot der Attractap-Hardware … -->`).
Folgendes wird für den Flyer benötigt und ist **nicht vorhanden**:

| Gerät | Status | Notiz |
|---|---|---|
| **Attractap** (NFC-Leser) | ❌ fehlt | Varianten: *Lite Ethernet*, *Touch WiFi*, *Touch Ethernet*; Kernkomponenten ESP32-MCU + PN532-NFC-Leser. |
| **Zigbee-Schaltbox** | ❌ fehlt | App-seitig via MQTT/Zigbee unterstützt; kein Produktfoto. |
| **Smartes Türschloss** | ❌ fehlt | Türsteuerung vorhanden; kein Produktfoto. |
| **Zigbee-Gateway** | ❌ fehlt | Kein Produktfoto. |
| **NFC-Karte (mit Logo)** | ❌ fehlt | Kein Produktfoto; nur Doku-Text zu NFC-Karten. |

Nächstgelegenes vorhandenes Material (NICHT als Attraccess-Produktfoto verwenden):
`reference/ESP32-S3-Touch-LCD-4*.jpg` – Fotos des Waveshare-Entwicklerboards, auf dem
die Attractap-Touch-Variante basiert (Drittanbieter, ungebrandet), sowie PCB-/Schaltplan-
Dokumente unter `docs/research/`. **Empfehlung:** echte Produktfotos der gebrandeten
Hardware nachreichen (weißer/transparenter Hintergrund, ≥300 dpi).

---

## 4) Sonstiges (`brand/`)

| Datei | Beschreibung |
|---|---|
| `og-image.png` | 1200×630 Open-Graph-Bild. **Neu erstellt** aus echten Markenelementen (Lockup, Claim „Dein Schlüssel zum Makerspace", Markenfarben, Status-Badges). Im Repo existierte kein og-image. |

**Press-Kit / weitere Marketing-Assets:** im Repo **nicht vorhanden** (außer Logo/Icons,
s. o.). Kein dediziertes Pressematerial gefunden.

---

## Reproduktion

1. `pnpm serve` mit `STORAGE_ROOT=storage-demo` (Demo-DB, beeinflusst die echte Dev-DB nicht).
2. Seed-Skript: `scripts/seed-demo-flyer.sql` (bereinigt + füllt eine Kopie der Dev-DB).
3. Login Demo-Admin: `anna.becker` / `Demo1234!`.
4. Screenshots via `agent-browser` (Light Mode erzwungen über Init-Script, das
   `prefers-color-scheme: light` meldet).
